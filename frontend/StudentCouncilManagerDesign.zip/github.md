repo: pchernaev/ss-shift-tracker
branch: main

## Last sync

date: 2026-08-19T12:35:00Z

### Updated in this project

- Извлечени цветове, сенки, радиуси и шрифтове от `styles.css`
- Дизайн система (светла + тъмна тема) в „Дизайн система.dc.html“
- Същите токени, приложени върху PolinaDusheva/StudentCouncilManger

## Screen map

| Екран в проекта | Файлове в репото |
| --- | --- |
| Дизайн система — токени и компоненти | styles.css |
| Примерен екран „Отчитане на дежурство“ | index.html, styles.css, images/Logo_Student_Union_UE-Varna.png |

## Secondary repo

repo: PolinaDusheva/StudentCouncilManger
branch: main
path: frontend/src

| Екран в проекта | Файлове в репото |
| --- | --- |
| Дизайн система StudentCouncilManager — цветове, типография | frontend/src/index.css |
| Бутони и полета | components/ui/Button.tsx, Input.tsx, Select.tsx |
| Бейджове, alert, avatar, empty, pagination | components/ui/Badge.tsx, Alert.tsx, Avatar.tsx, EmptyState.tsx, Pagination.tsx |
| Обвивка на приложението | components/layout/AppShell.tsx |
| Таблица, дъска, модал | components/ui/Table.tsx, Modal.tsx, routes/tasks/TaskCard.tsx, TaskBoardPage.tsx, taskLabels.ts |
| Етикети и статуси | lib/types/enums.ts |
